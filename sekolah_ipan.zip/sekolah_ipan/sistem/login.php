<!DOCTYPE html>
<html>
<head>
  <title>login</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>


<div class="kotak_login">
  <p class="tulisan_login">login in here</p>
  <form action="cek_login.php" method="post">
    <label>username</label>
    <input type="text" name="username" class="form_login"placeholder="
    username .."required="requered">

    <label>password</label>
    <input type="password" name="password" class="form_login" placeholder="
    username .. "requred="requred">

    <input type="submit" class="tombol_login" value="login">




    <br/>
    <br/>
    <center>
      <a class="link" href="registrasi.php">REGISTRASI</a>
    </center>
  </form>
</div>



</body>
</html>