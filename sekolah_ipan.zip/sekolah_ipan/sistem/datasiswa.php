<!DOCTYPE html>
<html>
<head>
	<title>DATA SISWA</title>
  <link rel="stylesheet" type="text/css" href="../asset/style/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="../asset/style/css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="../asset/style/css/bootstrap-theme.min.css">
  <link rel="stylesheet" type="text/css" href="../asset/style/css/bootstrap-theme.css">
  <link rel="stylesheet" type="text/css" href="../asset/style/css/style.css">
</head>
<body>



  <nav class="navbar navbar-light" style="background: red">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
     
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        
        <li><a href="datasiswa.php">DATA SISWA</a></li>
        <li><a href="datakelas.php">DATA KELAS</a></li> 
        <li><a href="datajurusan.php">DATA JURUSAN</a></li>
       
      </ul>
      <form class="navbar-form navbar-left">
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Search">
        </div>

      </form>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="logout.php">LOGOUT</a></li>
       
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class="container">
	<div class="row">
	<div class="col-lg-12">
	<h2 align="left">DATA SISWA</h2>
  <br>  
  <center>  
      <a class="btn btn-success" href="tambahdatasiswa.php"><i class="glyphicon glyphicon-user"></i>TAMBAH DATA SISWA</a>

  </center>
</br>
	<?php
	include'koneksi.php' ;
$no = 1;
$data = mysqli_query($koneksi,"SELECT * FROM siswa INNER JOIN kelas ON siswa.id_kelas=kelas.id_kelas JOIN jurusan on kelas.id_jurusan=jurusan.id_jurusan");
      if (!$data) {
      die('SQL error:'. mysqli_error($koneksi));
      }
?>
<div class="container">
  <div class="row">
  <div class="col-lg-12">
  <br>  
  <center>  
      <a class="btn btn-success" href="export/pdf/siswa.php"><i class="glyphicon glyphicon-user"></i>Export To PDF</a>
      <a class="btn btn-success" href="upload_kelas_import.php"><i class="glyphicon glyphicon-user"></i>Import</a>

  </center>
<div class="table-responsive">
<table class="table table-bordered">
   <thead>
   <tr>

         <th>NO</th>
         <th>FOTO</th>
         <th>NIS</th>
         <th>NAMA</th>
         <th>JENIS_KELAMIN</th>
         <th>ALAMAT</th>
         <th>KELAS</th>
         <th>jURUSAN</th>
         <th>ACTION</th>
     </tr>
     </thead>
     <tbody>
<?php
     while ($d = mysqli_fetch_array($data))
   {
echo"
   	<tr>

      <td>" .$no++." </td>
     <td><img src =' ../asset/gambar/".$d['poto']."' width='100' height='100'></td>
     <td>".$d['nis']." </td>
     <td>".$d['nama']."</td>
     <td>".$d['jenis_kelamin']."</td>
     <td>".$d['alamat']."</td>
     <td>".$d['nama_kelas']."</td>
     <td>".$d['nama_jurusan']." </td>
     <td><a href='edit.php?id_siswa=$d[id_siswa]' class='glyphicon glyphicon-edit'>edit</a>
     <a href='aksi/delete.php?id_siswa=$d[id_siswa]' class='glyphicon glyphicon-trash')>delete</a>
     </td>

     </tr>";

   }


   echo '
     </tbody>
     </table>
     </div>';


     ?>
        </div>
       </div>
       </div>
       <div class="footer">
       <div class="container">
       <div class="row">
       <div class="col-lg-12">

       &copy; 2020. ipan pandani
</div>
</div>
</div>
</div>

    


     
     

</form>
<script src="../assets/style/js/jquery.js"></script>
<script src="../assets/style/js/bootstrap.min.js"></script>

</body>

</html>