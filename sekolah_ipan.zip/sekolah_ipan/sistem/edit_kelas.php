<?php
  include 'koneksi.php';
  $id = $_GET['id_kelas'];
$sql="SELECT * From kelas where id_kelas='$id'";
$query = mysqli_query($koneksi, $sql);


$row = mysqli_fetch_array($query);
    ?>
<!DOCTYPE html>
<html>
<head>
	<title>Edit</title><meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="../asset/style/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="../asset/style/css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="../asset/style/css/bootstrap-theme.min.css">
  <link rel="stylesheet" type="text/css" href="../asset/style/css/bootstrap-theme.css">
</head>

<body>
 <nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
     
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        
        <li><a href="datasiswa.php">Data Siswa</a></li>
        <li><a href="datakelas.php">Data Kelas</a></li> 
        <li><a href="datajurusan.php">Data Jurusan</a></li>
       
      </ul>
      <form class="navbar-form navbar-left">
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Search">
        </div>

      </form>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#">Link</a></li>
       
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<div class="container">
  <div class="row">
<h1>Edit Data Siswa</h1>

	
	<form method="post" action="update_kelas.php?act=edit" enctype="multipart/form-data">
    <input type="hidden" value="<?php echo $row['id_kelas'];?>" name="id_kelas">
    <table>
      
      <tr><td>Nama Kelas</td><td><input type="text" value="<?php echo $row['nama_kelas'];?>" name="nama_kelas"></td></tr>
      <tr><td>Tingkat</td>
<td>
  <select name="tingkat">
    <option value="1">X</option>
    <option value="2">XI</option>
    <option value="3">XII</option>
  </select>
</td></tr>
    
            <tr><td><br></td></tr>
            <tr><td><button class="btn btn-success" type="submit" value="simpan"><i class="fas fa-save"></i>Simpan</button></td>
                <td><button class="btn btn-danger" type="cancel"> <i class="fas fa-times"><a href="datakelas.php" class="a">Kembali</a></i></button></td>
            </tr>
      
    </table>
  </form>
		<?php 
	
	?>
        </div>
       </div>
       </div>
       <div class="footer">
       <div class="container">
       <div class="row">
       <div class="col-lg-12">

       &copy; 2020.Ipan pandani
</div>
</div>
</div>
</div>

    


     
     

</form>
<script src="../assets/style/js/jquery.js"></script>
<script src="../assets/style/js/bootstrap.min.js"></script>

</body>
</html>