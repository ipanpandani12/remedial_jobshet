<?php 

header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=Data siswa.xls");
 ?>


 <table border="1">
 	<tr>
         <th>no</th>
         <th>foto</th>
         <th>nis</th>
         <th>nama</th>
         <th>jenis_kelamin</th>
         <th>alamat</th>
         <th>kelas</th>
         <th>jurusan</th>

     </tr>
     <?php 
     include"../koneksi.php";
$sql ='SELECT *  FROM siswa INNER JOIN kelas ON siswa.id_kelas=kelas.id_kelas JOIN jurusan on kelas.id_jurusan=jurusan.id_jurusan';
 $query = mysqli_query($koneksi, $sql);
 $no = 1;
 while ($row = mysqli_fetch_array($query)) {
 	?>
 	<tr>
     <td> <?php echo $no++; ?></td>
     <td> </td>
     <td> <?php echo $row['nis']; ?></td>
     <td> <?php echo $row['nama']; ?></td>
     <td> <?php echo $row['jenis_kelamin']; ?></td>
     <td> <?php echo $row['alamat']; ?></td>
     <td> <?php echo $row['nama_kelas']; ?></td>
     <td> <?php echo $row['nama_jurusan']; ?></td>
     
</tr>
<?php
}
 ?>

    
  
 </table>