

<?php
include '../koneksi.php';

	$program = @$_POST['program'];
	$keterangan = @$_POST['keterangan'];
	

	
	$a="SELECT * from jurusan where nama_jurusan='$program' and keterangan= 'keterangan'";
	$u=mysqli_query($koneksi, $a);
	$cek = mysqli_num_rows($u);
	if ($cek > 0) {
		echo "<script>window.alert('Data yang anda masukan sudah ada!!!')
			window.location='../datajurusan.php'
		</script>";
	}else{
		$sql ="INSERT into jurusan values('','$program','$keterangan') ";
	$query = mysqli_query($koneksi, $sql) or die ('Sql Error:'.mysqli_error($koneksi));
	echo "<script>window.alert('Data Di Simpan')
			window.location='../datajurusan.php'
		</script>";






}



?>
