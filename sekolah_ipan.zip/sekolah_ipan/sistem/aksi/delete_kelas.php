<?php
include'../koneksi.php';
$id = $_GET['id_kelas'];

$sql="DELETE from kelas where id_kelas='$id'";
$query= mysqli_query($koneksi, $sql);
echo "<script>window.alert('Data suksess di Hapus')
		window.location='../datakelas.php'
	</script>";
 ?> 